onload=start();
function start(){
	$display();
}

function $display(){
	function $getid(getid){
		return	document.getElementsByClassName(getid);
	}
	function $displayitem(idone,indexone,idtwo,indextwo){	
		var oneid=$getid(idone)[indexone];
		var twoid=$getid(idtwo)[indextwo];
		oneid.addEventListener("mouseover",blockitem);
		oneid.addEventListener("mouseout",noneitem);
		function blockitem(){
			twoid.style.display="block";
		}
		function noneitem(){
			twoid.style.display="none";
		}
	}
	for(var i=0;i<$getid("top-div-li").length;i++){
		$displayitem("top-div-li",i+1,"top-display-ul",i);
	}
}
