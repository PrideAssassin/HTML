$(document).ready(function(){
			$display();
			function $display(){
				function $getid(getid){
					return	document.getElementsByClassName(getid);
				}
				function $displayitem(idone,indexone,idtwo,indextwo){	
					var oneid=$getid(idone)[indexone];
					var twoid=$getid(idtwo)[indextwo];
					oneid.addEventListener("mouseover",blockitem);
					oneid.addEventListener("mouseout",noneitem);
					function blockitem(){
						twoid.style.display="block";
					}
					function noneitem(){
						twoid.style.display="none";
					}
				}
					for(var i=0;i<$getid("top-div-li").length;i++){
						$displayitem("top-div-li",i,"top-display-ul",i);	
					}	
			}		
			
			start1();
			function start1(){
				var imgs=["img/c.jpg","img/c1.jpg","img/c3.jpg"];
				var index=0;
				start();
				function start(){	
					setTimeout(play,2000);	
					function play(){	
						document.getElementById("content").style.backgroundImage="url("+imgs[index]+")";
						index++;
						if(index==imgs.length){	
							index=0;
						}
						start();	
					}
				}
			}
			
			
		yd1();
		function yd1(){
			var one=document.getElementById("content-fourdiv1");
			var two=document.getElementsByClassName("c4span");
			two[0].addEventListener("click",yd);
			two[1].addEventListener("click",yd);
			function yd(){
				var one=document.getElementById("content-fourdiv1");
				var two=document.getElementsByClassName("c4span");
				if(one.style.transform=="translateX(-840px)"){
					one.style.transform="translateX(0)"
				}else{
					one.style.transform="translateX(-840px)"
				}
			}
		}
		
		
						
})