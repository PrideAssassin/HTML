package com.student.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.student.domain.Student;
import com.student.service.StudentService;

public class StudentAction extends ActionSupport implements ModelDriven<Student> {

	private Student student = new Student();

	@Override
	public Student getModel() {
		return student;
	}
	
	//注入studentService
	private StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}


	/**
	 * 查询所有的学生
	 * 
	 * @return searchAll
	 */
	public String searchAll() {
		// 调用查询所有学生记录的业务逻辑
		List<Student> allStudents = studentService.searchAllStudents();
		// 将学生的所有记录保存到request范围里
		ServletActionContext.getRequest().setAttribute("list_students", allStudents);

		return "searchAll";
	}

	/**
	 * 更新页面
	 * @return updateUI
	 */
	public String updateUI()
	{		
		// 获取到请求过来的ID值
		String id = ServletActionContext.getRequest().getParameter("id");
		// 通过ID，查询数据库表，获取这个学生的对象
		Student student = studentService.getStudent(Integer.parseInt(id));
		// 将student对象保存到session里
		ActionContext.getContext().getSession().put("get_student", student);
		// 转向一个修改学生页面
		return "updateUI";
	}
	
	/**
	 * 更新学生
	 * @return update
	 */
	public String update()
	{
		// 调用更新学生的业务逻辑
		studentService.updateStudent(student);
		return "update";
	}
	
	/**
	 * 删除学生
	 * @return delete
	 */
	public String delete()
	{
		String id = ServletActionContext.getRequest().getParameter("id");
		//删除学生
		studentService.deleteStudent(Integer.parseInt(id));
		return "delete";
	}
}
