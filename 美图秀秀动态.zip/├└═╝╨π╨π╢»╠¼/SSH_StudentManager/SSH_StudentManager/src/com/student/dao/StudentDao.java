package com.student.dao;

import java.util.List;

import com.student.domain.Student;

/**
 * 学生数据库访问接口
 * 
 * @author david.yin
 *
 */
public interface StudentDao {

	/**
	 * 查询所有的学生记录
	 * 
	 * @return 学生的集合
	 */
	List<Student> selectAllStudents();

	/**
	 * 通过ID查询学生记录
	 * 
	 * @param id
	 *            ID
	 * @return Student
	 */
	Student selectStudent(int id);

	/**
	 * 更新学生
	 * 
	 * @param student
	 *            学生对象
	 */
	void updateStudent(Student student);
	
	/**
	 * 删除学生
	 * @param id 学生ID
	 */
	void deleteStudent(int id);
}
