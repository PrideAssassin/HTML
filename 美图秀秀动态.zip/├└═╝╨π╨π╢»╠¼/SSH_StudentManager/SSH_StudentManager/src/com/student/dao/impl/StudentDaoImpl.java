package com.student.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.classic.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.student.dao.StudentDao;
import com.student.domain.Student;

public class StudentDaoImpl extends HibernateDaoSupport implements StudentDao {

	@Override
	public List<Student> selectAllStudents() {
		String searchAllStudentHql = "from Student";
		/* searchAllStudentHql="select stu from Student stu"; */
		@SuppressWarnings("unchecked")
		List<Student> students = this.getHibernateTemplate().find(searchAllStudentHql);
		return students;
	}

	@Override
	public Student selectStudent(int id) {
		Student student = this.getHibernateTemplate().get(Student.class, id);
		return student;
	}

	@Override
	public void updateStudent(Student student) {
		this.getHibernateTemplate().update(student);
	}

	/**
	 * 删除学生 （hibernate3调用原始的sql语句）
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void deleteStudent(int id) {
		Session session = this.getHibernateTemplate().getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Connection connection = session.connection();
		try {
			SQLQuery sqlUpdate = session.createSQLQuery("UPDATE score set sid=NULL WHERE sid=" + id);
			sqlUpdate.executeUpdate();

			SQLQuery sqlDelete = session.createSQLQuery("delete from student where sid=" + id);
			sqlDelete.executeUpdate();

			connection.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (session != null)
				session.close();

		}

	}

}
