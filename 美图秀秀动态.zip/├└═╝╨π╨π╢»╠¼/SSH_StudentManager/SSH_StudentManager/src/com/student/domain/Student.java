package com.student.domain;

//文档注释
/**
 * 学生模型
 * @author david.yin
 *
 */
public class Student {

	//学生的编号
	private Integer id;
	//学生的姓名
	private String name;
	//年龄
	private Integer age;
	//性别
	private String sex;


	/**
	 * 获取ID
	 * @return ID
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * 设置ID
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 获取学生的姓名
	 * @return 学生的姓名
	 */
	public String getName() {
		return name;
	}

	/**
	 * 设置学生的名字
	 * @param name 学生的名字
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 获取年龄
	 * @return 学生的年龄
	 */
	public Integer getAge() {
		return age;
	}

	/**
	 * 设置年龄
	 * @param age
	 */
	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 * 获取性别
	 * @return 性别,"男"或者"女"
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * 设置性别
	 * 
	 * @param sex "男"或者"女"
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", sex=" + sex + "]";
	}	
	

}
