package com.student.service.impl;

import java.util.List;

import com.student.dao.StudentDao;
import com.student.dao.impl.StudentDaoImpl;
import com.student.domain.Student;
import com.student.service.StudentService;

public class StudentServiceImpl implements StudentService {
	
	//注入studentDao
	private StudentDao studentDao;	
	
	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	/**
	 * 查询所有学生
	 */
	@Override
	public List<Student> searchAllStudents() {		
		return studentDao.selectAllStudents();	
	}

	/**
	 * 更新学生
	 * @param student 学生对象
	 */
	public void updateStudent(Student student) {
		studentDao.updateStudent(student);	
	}

	/**
	 * 通过Id获取学生对象信息
	 * @param id 学生的编号
	 * @return 该ID的学生对象
	 */
	public Student getStudent(int id) {
		return studentDao.selectStudent(id);		
	}

	public void deleteStudent(int id) {
		studentDao.deleteStudent(id);
	}

}
