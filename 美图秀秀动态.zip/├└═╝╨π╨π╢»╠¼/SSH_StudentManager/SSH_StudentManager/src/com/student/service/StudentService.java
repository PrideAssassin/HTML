package com.student.service;

import java.util.List;

import com.student.domain.Student;

/**
 * 学生业务的接口
 * 
 * @author david.yin
 *
 */
public interface StudentService {
	/**
	 * 查询所有的学生记录
	 * 
	 * @return 学生的集合
	 */
	List<Student> searchAllStudents();

	void deleteStudent(int id);

	Student getStudent(int id);

	void updateStudent(Student student);
}
